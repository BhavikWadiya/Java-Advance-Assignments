package com.shoppingcart.interfaces;

import java.util.List;

import com.shoppingcart.model.Product;

public interface ProductDAO {
	
	public void addProduct(Product prod);
	public Product findProductById(int id);
	public void deleteProductById(Product prod);
	public void updateProduct(Product prod);
	public List<Product> findByCategory(String category);
	public List<Product> findByBrandAndModel(String brand, String model);
	public List<Product> findByBrandOrModel(String brandOrModel);
	public List<Product> findByBrandOrModelOrCategory(String BrandOrModelOrCategory);
	
}
