package com.shoppingcart.implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.shoppingcart.interfaces.ProductDAO;
import com.shoppingcart.model.Product;

public class ProductDaoImpl implements ProductDAO{

	@Autowired
	private HibernateTemplate template;
	
	public void addProduct(Product prod) {
		template.save(prod);
	}

	public Product findProductById(int id) {
		Product p = (Product) template.get(Product.class,id);
		return p;
	}

	public void deleteProductById(Product prod) {
		template.delete(prod);
	}

	public void updateProduct(Product prod) {
		template.update(prod);
	}

	public List<Product> findByCategory(String category) {
		List<Product> allProducts = template.loadAll(Product.class);
		List<Product> result = new ArrayList<Product>();
		for(Product p:allProducts)
		{
			if(p.getCategory().equals(category))
			{
				result.add(p);
			}
		}
		return result;
	}

	public List<Product> findByBrandAndModel(String brand, String model) {
		List<Product> allProducts = template.loadAll(Product.class);
		List<Product> result = new ArrayList<Product>();
		for(Product p:allProducts)
		{
			if(p.getBrand().equals(brand) && p.getModel().equals(model))
			{
				result.add(p);
			}
		}
		return result;
	}

	public List<Product> findByBrandOrModel(String brandOrModel) {
		List<Product> allProducts = template.loadAll(Product.class);
		List<Product> result = new ArrayList<Product>();
		for(Product p:allProducts)
		{
			if(p.getBrand().equals(brandOrModel) || p.getModel().equals(brandOrModel))
			{
				result.add(p);
			}
		}
		return result;
	}

	public List<Product> findByBrandOrModelOrCategory(String brandOrModelOrCategory) {
		List<Product> allProducts = template.loadAll(Product.class);
		List<Product> result = new ArrayList<Product>();
		for(Product p:allProducts)
		{
			if(p.getBrand().equals(brandOrModelOrCategory) || p.getModel().equals(brandOrModelOrCategory) || p.getCategory().equals(brandOrModelOrCategory))
			{
				result.add(p);
			}
		}
		return result;
	}

}
