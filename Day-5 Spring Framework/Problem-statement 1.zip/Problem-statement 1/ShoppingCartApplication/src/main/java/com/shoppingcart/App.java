package com.shoppingcart;

import org.springframework.context.annotation.ComponentScan;

import com.shoppingcart.implementation.ProductDaoImpl;
import com.shoppingcart.implementation.ProductServiceImpl;
import com.shoppingcart.model.Product;

@ComponentScan(basePackages = "com.shoppingcart")
public class App 
{
	
    public static void main( String[] args )
    {
        Product p = new Product("iPhone", 42000, 1, "Apple", "12 Mini", "Mobile");
        ProductDaoImpl ps = new ProductDaoImpl();
        ps.addProduct(p);
        
    }
}
