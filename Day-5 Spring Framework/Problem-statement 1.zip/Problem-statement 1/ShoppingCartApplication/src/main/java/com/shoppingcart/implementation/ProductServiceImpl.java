package com.shoppingcart.implementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.shoppingcart.interfaces.ProductService;
import com.shoppingcart.model.Product;

public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductDaoImpl productDAO;

	public void addProduct(Product prod) {
		productDAO.addProduct(prod);
	}

	public Product findProductById(int id) {
		return productDAO.findProductById(id);
	}

	public void deleteProductById(Product prod) {
		productDAO.deleteProductById(prod);
	}

	public void updateProduct(Product prod) {
		productDAO.updateProduct(prod);
	}

	public List<Product> findByCategory(String category) {
		return productDAO.findByCategory(category);
	}

	public List<Product> findByBrandAndModel(String brand, String model) {
		return productDAO.findByBrandAndModel(brand, model);
	}

	public List<Product> findByBrandOrModel(String brandOrModel) {
		return productDAO.findByBrandOrModel(brandOrModel);
	}

	public List<Product> findByBrandOrModelOrCategory(String BrandOrModelOrCategory) {
		return productDAO.findByBrandOrModelOrCategory(BrandOrModelOrCategory);
	}

}
