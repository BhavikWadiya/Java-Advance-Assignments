package practice;

public class ExtendedRectangle {
	
	private float length;
	private float breadth;
	
	public ExtendedRectangle(int length, int breadth)
	{
		this.length = length;
		this.breadth = breadth;
	}
		
	public float getLength() {
		return length;
	}


	public void setLength(float length) {
		if(length>0.0 && length<20.0)
		{
			this.length = length;
		}
		else
		{
			System.out.println("Error!! Please Enter length between 0.0 and 20.0");
		}
	}


	public float getBreadth() {
		return breadth;
	}


	public void setBreadth(float breadth) {
		if(breadth>0.0 && breadth<20.0)
		{
			this.breadth = breadth;
		}
		else
		{
			System.out.println("Error!! Please Enter breadth between 0.0 and 20.0");
		}
	}

	public int perimeter(int len, int bth)
	{
		return 2*(len+bth);
	}
	
	public int area(int len, int bth)
	{
		return len*bth;
	}
	
	public void rectangleInfo()
	{
		System.out.println("Length of Rectangle is: "+length);
		System.out.println("Breadth of Rectangle is: "+breadth);
		System.out.println("Area of Rectangle is: "+ length*breadth);
	}

	
}
