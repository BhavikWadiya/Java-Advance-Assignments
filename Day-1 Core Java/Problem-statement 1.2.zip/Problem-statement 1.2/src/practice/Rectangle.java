package practice;

public class Rectangle {
	
	private int length;
	private int breadth;
	
	public Rectangle(int length, int breadth)
	{
		this.length = length;
		this.breadth = breadth;
	}
	
	public void rectangleInfo()
	{
		int area = length * breadth;
		System.out.println("Length of Rectangle is: "+length);
		System.out.println("Breadth of Rectangle is: "+breadth);
		System.out.println("Area of Rectangle is: "+area);
	}

}
