package practice;

import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		for(int i=1; i<=5; i++)
		{
			System.out.println("Enter the Length of "+i+" object");
			int length = sc.nextInt();
			System.out.println("Enter the Breadth of "+i+" object");
			int breadth = sc.nextInt();
			Rectangle obj = new Rectangle(length,breadth);
			obj.rectangleInfo();
		}
		sc.close();
	}

}
