package practice;

import java.util.Scanner;

public class SplitString {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the equation: ");
		String eq = sc.nextLine();
		String[] parts = eq.split("\\s");
		
		for(int i=0; i<parts.length; i++)
		{
			System.out.println(parts[i]);
		}
		sc.close();
	}
}
