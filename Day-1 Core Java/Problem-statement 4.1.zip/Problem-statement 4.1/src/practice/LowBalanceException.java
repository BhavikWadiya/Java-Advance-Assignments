package practice;

@SuppressWarnings("serial")
public class LowBalanceException extends Exception{

	public LowBalanceException(String errorMsg)
	{
		super(errorMsg);
	}
}
