package practice;

@SuppressWarnings("serial")
public class InsufficientFundsException extends Exception{

	public InsufficientFundsException(String errorMsg)
	{
		super(errorMsg);
	}
}
