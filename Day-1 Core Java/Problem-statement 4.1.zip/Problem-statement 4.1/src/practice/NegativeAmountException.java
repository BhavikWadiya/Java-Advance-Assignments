package practice;

@SuppressWarnings("serial")
public class NegativeAmountException extends Exception{

	public NegativeAmountException(String errorMsg)
	{
		super(errorMsg);
	}
}
