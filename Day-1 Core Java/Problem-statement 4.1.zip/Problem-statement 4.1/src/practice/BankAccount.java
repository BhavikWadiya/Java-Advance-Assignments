package practice;

public class BankAccount {
	
	int accNo;
	String custName;
	String accType;
	float balance;
	
	public void deposit(float amt) throws NegativeAmountException
	{
		if(amt<0)
		{
			throw new NegativeAmountException("Amount cannot be negative");
		}
		else
		{
			balance = balance+amt;
		}
	}
	
	public void withdraw(float amt) throws InsufficientFundsException
	{
		if(accType=="Savings")
		{
			if((balance-amt)<1000)
			{
				throw new InsufficientFundsException("Amount in your "+accType+" account is not sufficient to process this transaction");
			}
		}
	}
	
	public float getBalance()
	{
		return balance;
	}
	
	public BankAccount(int accNo, String custName, String accType, float balance)
	{
		this.accNo = accNo;
		this.custName = custName;
		this.accType = accType;
		this.balance = balance;
	}
	
	public static void main(String[] args) throws Exception
	{
		BankAccount acc1 = new BankAccount(101, "Bhavik Wadiya", "Current", 5001);
		
		if(acc1.balance<0)
		{
			throw new NegativeAmountException("Balance Cannot be less then 0");
		}
		
		if((acc1.balance<1000 && acc1.accType=="Savings") || (acc1.balance<5000 && acc1.accType=="Current"))
		{
			throw new LowBalanceException("Balance is Low");
		}
		
	}
}
