package practice;

import java.util.Scanner;

public class PlayingWithStrings {
	 
	 public boolean isPalindrome(String s)
	 {
		 int i=0, j=s.length()-1;
		 while(i<j)
		 {
			 if(s.charAt(i)!=s.charAt(j))
			 {
				 return false;
			 }
			 i++;
			 j--;
		 }
		 return true;
	 }
	 
	 public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.next();
		System.out.println("Entered String is: "+str);
		System.out.println("The length of string is: "+str.length());
		System.out.println("String in Uppercase is: "+str.toUpperCase());
		PlayingWithStrings obj = new PlayingWithStrings();
		boolean result = obj.isPalindrome(str);
		System.out.println("Is this String Palindrome: "+result);
		sc.close();
	}
}
