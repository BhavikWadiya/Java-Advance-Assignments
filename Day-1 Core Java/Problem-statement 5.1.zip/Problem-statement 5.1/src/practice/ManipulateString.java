package practice;

public class ManipulateString {

	public static void main(String[] args) {
		
		String str = "JAVA is Simple";
		
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		
		String[] splittedString = str.split(" ");
		for(int i=0; i<splittedString.length; i++)
		{
			System.out.print(splittedString[i].charAt(0)+" ");
		}
		
		System.out.println();
		
		for(int j=splittedString.length-1; j>=0; j--)
		{
			System.out.print(splittedString[j]+" ");
		}
		
		System.out.println();
		
		for(int k=0; k<splittedString.length; k++)
		{
			StringBuilder sb = new StringBuilder(splittedString[k]);
			StringBuilder reversed = sb.reverse();
			System.out.print(reversed+" ");
		}
		
		System.out.println();
		
		System.out.println(str.length());
	}
}
