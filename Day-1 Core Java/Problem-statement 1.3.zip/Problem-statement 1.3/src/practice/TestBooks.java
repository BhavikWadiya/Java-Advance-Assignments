package practice;

import java.util.Scanner;

public class TestBooks {

	Books books[] = new Books[10];
	int i=0;
	
	public void createBook(String title, double price)
	{
		Books book = new Books();
		book.setBookTitle(title);
		book.setBookPrice(price);
		books[i]=book;
		i++;
		System.out.println("Book named "+title+" added");
	}
	
	public void showBook(int choice)
	{
		for(int j=1; j<=choice; j++)
		{
			System.out.println("Title of "+j+" book: "+books[j-1].getBookTitle());
			System.out.println("Price of "+j+" book: "+books[j-1].getBookPrice());
		}
	}
	
	public static void main(String[] args) {
		TestBooks tb = new TestBooks();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of books you want to add: ");
		int choice = sc.nextInt();
		
		for(int k=0; k<choice; k++)
		{
			System.out.println("Enter the book title: ");
			String title = sc.next();
			System.out.println("Enter the book price: ");
			double price = sc.nextDouble();
			tb.createBook(title, price);
		}
		
		tb.showBook(choice);
		sc.close();
	}
}
