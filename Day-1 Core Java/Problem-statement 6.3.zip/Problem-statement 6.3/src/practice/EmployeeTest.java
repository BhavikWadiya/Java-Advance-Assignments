package practice;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class EmployeeTest {
	
	LinkedList<Employee> employeeList = new LinkedList<Employee>();
	
	public void addInput(Employee e)
	{
		employeeList.add(e);
		System.out.println("Employee added");
	}
	
	@SuppressWarnings("rawtypes")
	public void displayReverse()
	{
		Iterator x = employeeList.descendingIterator();
		while(x.hasNext())
		{
			System.out.println(x.next());
		}
	}
	
	@SuppressWarnings("rawtypes")
	public void displayFront()
	{
		Iterator z = employeeList.listIterator();
		while(z.hasNext())
		{
			System.out.println(z.next());
		}
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		EmployeeTest empTest = new EmployeeTest();

		Scanner sc = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter the number of Employees you want to add");
		int choice = sc.nextInt();
		
		for(int i=0; i<choice; i++)
		{
			System.out.println("Enter the id of "+(i+1)+" employee");
			int id = sc.nextInt();
			System.out.println("Enter the name of "+(i+1)+" employee");
			String name = sc2.nextLine();
			System.out.println("Enter the address of "+(i+1)+" employee");
			String address = sc2.nextLine();
			Employee emp = new Employee(id, name, address);
			empTest.addInput(emp);
		}
		
		System.out.println();
		System.out.println("Displaying LinkedList from Front");
		empTest.displayFront();
		
		System.out.println();
		System.out.println("Displaying LinkedList from Rear");
		empTest.displayReverse();
	}
}
