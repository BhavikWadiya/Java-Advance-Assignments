package practice;

public class Employee {
	
	int employeeNo;
	String employeeName;
	String employeeAddress;
	
	public Employee(int empNo, String empName, String empAdd)
	{
		this.employeeNo = empNo;
		this.employeeName = empName;
		this.employeeAddress = empAdd;
	}

	@Override
	public String toString() {
		return "Employee [employeeNo=" + employeeNo + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + "]";
	}

	
}
