package practice;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentList {

	public static void main(String[] args) {
		ArrayList<String> studentNames = new ArrayList<String>();
		
		while(true)
		{
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in); 
			System.out.println("-----------Students List----------");
			System.out.println("1. Add Student");
			System.out.println("2. Search Student");
			System.out.println("3. Exit");
			int choice = sc.nextInt();
			
			if(choice==1)
			{
				System.out.println("Enter name of Student: ");
				String studName = sc.next();
				studentNames.add(studName);
				System.out.println("Student "+studName+" added");
			}
			
			else if(choice==2)
			{
				System.out.println("Enter the name of Student you are searching for: ");
				String searchVal = sc.next();
				int result = studentNames.indexOf(searchVal);
				if(result==-1)
				{
					System.out.println("Student "+searchVal+" does not exist in List");
				}
				else
				{
					System.out.println("Student "+searchVal+" is present in List at index "+result);
				}
			}
			
			else if(choice==3)
			{
				sc.close();
				break;
			}
		}
	}
	
}
