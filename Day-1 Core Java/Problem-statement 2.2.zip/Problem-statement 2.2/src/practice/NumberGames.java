package practice;

import java.util.Scanner;

public class NumberGames {
	
	public static void nextSequence(int num1, int num2)
	{
		int a = num1;
		int b = num2;
		System.out.println(a);
		System.out.println(b);
		for(int i=0; i<13; i++)
		{
			int c = a+b;
			System.out.println(c);
			a=b;
			b=c;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter First Number: ");
		int first = sc.nextInt();
		System.out.println("Enter Second Number: ");
		int second = sc.nextInt();
		
		System.out.println("First Number is: "+first);
		System.out.println("Second Number is: "+second);
		
		System.out.println("Sequence is: ");
		nextSequence(first, second);
		sc.close();
		
	}
}
