package practice;

public class Ointment implements MedicineInfo{
	
	@Override
	public void displayLabel()
	{
		System.out.println("For external use only");
	}

}
