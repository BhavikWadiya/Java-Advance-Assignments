package practice;

public class Tablet implements MedicineInfo{

	@Override
	public void displayLabel() {
		System.out.println("Store in cool and dry place");
	}

}
