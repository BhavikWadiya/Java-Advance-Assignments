package practice;

public interface MedicineInfo {

	abstract void displayLabel();
}
