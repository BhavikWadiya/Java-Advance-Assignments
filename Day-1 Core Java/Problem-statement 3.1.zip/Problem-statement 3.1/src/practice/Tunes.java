package practice;

public class Tunes {
	public static void main(String[] args) {
		
		Instrument instruments[] = new Instrument[10];
		instruments[0] = new Guitar();
		instruments[1] = new Piano();
		instruments[2] = new Flute();
		instruments[3] = new Piano();
		instruments[4] = new Flute();
		instruments[5] = new Guitar();
		instruments[6] = new Piano();
		instruments[7] = new Guitar();
		instruments[8] = new Flute();
		instruments[9] = new Piano();
		
		for(int i=0; i<instruments.length; i++)
		{
			if(instruments[i] instanceof Piano)
			{
				instruments[i].play();
			}
			else if(instruments[i] instanceof Flute)
			{
				instruments[i].play();
			}
			else if(instruments[i] instanceof Guitar)
			{
				instruments[i].play();
			}
		}
	}
}
