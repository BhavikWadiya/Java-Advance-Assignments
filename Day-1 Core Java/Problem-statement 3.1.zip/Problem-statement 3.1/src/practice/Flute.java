package practice;

public class Flute extends Instrument{

	@Override
	void play() {
		System.out.println("Flute is playing toot toot toot toot");
	}

}
