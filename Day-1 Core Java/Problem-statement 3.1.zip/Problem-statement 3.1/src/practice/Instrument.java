package practice;

abstract class Instrument {
	
	abstract void play();
}
