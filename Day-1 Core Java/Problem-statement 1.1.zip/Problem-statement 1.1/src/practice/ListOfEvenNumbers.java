package practice;

import java.util.Scanner;

public class ListOfEvenNumbers {
	
	public static void listOfNumbers(int n)
	{
		for(int i=0; i<=n; i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number till which you want to get even numbers: ");
		int n = sc.nextInt();
		listOfNumbers(n);
		sc.close();
	}

}
