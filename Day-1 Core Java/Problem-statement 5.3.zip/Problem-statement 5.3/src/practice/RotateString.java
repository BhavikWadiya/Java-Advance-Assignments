package practice;

import java.util.Scanner;

public class RotateString {
	
	public static void rotate(String str)
	{		
		int len = str.length();
		for(int i=0; i<=len; i++)
		{
			StringBuffer sb = new StringBuffer();
			int j=i;
			int k=0;
			
			for(int l=j; l<len; l++)
			{
				sb.insert(k, str.charAt(j));
				k++;
				j++;
			}
			j=0;
			while(j<i)
			{
				sb.insert(k, str.charAt(j));
				j++;
				k++;
			}
			System.out.println(sb);
		}
		
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String you want to rotate: ");
		String str = sc.next();
		rotate(str);
		sc.close();
	}
}
