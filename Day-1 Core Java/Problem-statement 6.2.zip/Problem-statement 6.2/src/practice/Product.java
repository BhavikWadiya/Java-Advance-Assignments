package practice;

import java.util.Hashtable;
import java.util.Scanner;

public class Product {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Hashtable<String,String> product = new Hashtable<>();
		Scanner sc = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		
		System.out.println("Enter the number of products you want to add: ");
		int n = sc.nextInt();
		
		for(int i=0; i<n; i++)
		{
			System.out.println("Enter the Product id: ");
			String id = sc.next();
			System.out.println("Enter the Product name: ");
			String name = sc2.nextLine();
			product.put(id, name);
		}
		
		while(true)
		{
			System.out.println("----------Product Operations--------");
			System.out.println("1. Search Product");
			System.out.println("2. Remove Product");
			System.out.println("3. Exit");
			
			int choice = sc.nextInt();
			
			if(choice==1)
			{
				System.out.println("Enter the name of Product to be searched: ");
				String searchVal = sc2.nextLine();
				if(product.containsValue(searchVal))
				{
					System.out.println("Product "+searchVal+" exists in Hashtable");
				}
				else
				{
					System.out.println("Product "+searchVal+" does not exist in Hashtable");
				}
			}
			
			else if(choice==2)
			{
				System.out.println("Enter the id of product to be removed: ");
				String id = sc.next();
				product.remove(id);
				System.out.println("Product with id "+id+" removed");
			}
			
			else if(choice==3)
			{
				break;
			}
		}
	}
}
